rootProject.name = "financeService"
